# FSCD Experiment Scripts

This is the clean rerun layout for the FSCD state-canonization experiments.

Each width has its own folder:

- `pw1`, `pw2`, `pw3`, `pw4`, `pw5`
- `tw1`, `tw2`, `tw3`, `tw4`

Each folder owns:

- `create_property_files.py`: creates the TreeWidzard property/input files.
- `create_jobs.py`: creates the SLURM job scripts.
- `properties/`: generated TreeWidzard property files.
- `jobs/`: generated SLURM scripts.
- `logs/`: SLURM stdout/stderr files.
- `outputs/`: TreeWidzard program outputs.
- `metadata/`: generated CSV metadata.

TreeWidzard is not copied into this folder. Set its path in `config.env` or export it before submitting:

```bash
export TREEWIDZARD_BIN=/absolute/path/to/treewidzard
```

## Generate

Create the layout if needed:

```bash
python3 generate_layout.py
```

Generate all property files and job scripts:

```bash
./generate_all.sh
```

Or generate one width:

```bash
cd pw5
python3 create_property_files.py
python3 create_jobs.py
```

## Submit

Submit all generated jobs:

```bash
./submit_all_jobs.sh
```

Or submit one width:

```bash
cd pw5
./submit_jobs.sh
```

The generated jobs fail immediately if `TREEWIDZARD_BIN` is not set. Use the `submit_jobs.sh` scripts after uploading to Saga; they pass the current cluster-side folder to `sbatch`, so logs and outputs stay under each `pw*`/`tw*` directory without hardcoded local paths.

## Resource Policy

The default profile uses `32` CPUs, `-nthreads 32`, about `160G` total memory, and a one-day wall time.

Archived unfinished cases keep the same one-day wall time as the FSCD paper jobs, with resource changes only where needed:

- old OOM cases: `bigmem`, `16G` per CPU, about `512G` total memory.
- old timeout cases: one day, about `160G` total memory.
- old segfault cases: one-day debug reruns, because those failures were crashes rather than resource exhaustion.

The `pw5` folder also gets a `paper_flagship` job for the `pw=5`, `Delta=3`, premise, `PIBFS` run with `128` TreeWidzard threads.
